---
layout: equipment
title:  "MiniLab 080 E-beam evaporation system"
image: minilab80.jpg
---
MiniLab 080 is ideally suited to evaporation techniques where long working distances are required for best uniformity, and where evaporant incident angles close to 90° allow for optimal results for lift-off applications.


### Specification:



### Technical Characteristics:

